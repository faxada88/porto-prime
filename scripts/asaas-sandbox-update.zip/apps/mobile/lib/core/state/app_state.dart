import 'dart:async';

import '../tracking/courier_route_tracker.dart';
import 'partner_referral.dart';

import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';

import '../network/api_client.dart';
import '../realtime/realtime_client.dart';
import '../notifications/courier_offer_alerts.dart';

class AppState extends ChangeNotifier {
  final Set<String> removedOrderIds = {};
  bool useCustomerCredit = false;
  double customerCreditRequested = 0;
  double get cartTotalBeforeCredit =>
      cartSubtotal +
      (double.tryParse(deliveryQuote['deliveryFee']?.toString() ?? '') ?? 0);
  double customerCreditLimit([double? available, double? total]) {
    final balance = ((available ?? customerCreditBalance) * 100).round();
    final bill = ((total ?? cartTotalBeforeCredit) * 100).round();
    return (balance >= bill ? bill : min(balance, max(0, bill - 50))) / 100;
  }

  double selectedCustomerCredit([double? available, double? total]) =>
      !isCustomer || !useCustomerCredit
      ? 0
      : ((customerCreditRequested.clamp(
                      0,
                      customerCreditLimit(available, total),
                    ) *
                    100)
                .round() /
            100);
  void chooseCustomerCredit(bool use, {double? amount}) {
    useCustomerCredit = use;
    customerCreditRequested = use ? (amount ?? customerCreditLimit()) : 0;
    notifyListeners();
  }

  double customerCreditBalance = 0;
  Map<String, dynamic> customerCreditCard = {};
  Future<void> loadCustomerCredit() async {
    if (!isCustomer) {
      customerCreditBalance = 0;
      customerCreditCard = {};
      useCustomerCredit = false;
      customerCreditRequested = 0;
      return;
    }
    final customerId = user?["id"];
    final result = await api.request("GET", "/orders/credits");
    if (!isCustomer || user?["id"] != customerId) return;
    customerCreditCard = Map<String, dynamic>.from(result);
    customerCreditBalance =
        double.tryParse(result["available"].toString()) ?? 0;
    notifyListeners();
  }

  Future<void> resolveUnavailable(
    String orderId,
    String itemId,
    String choice, {
    String? productId,
  }) async {
    await api.request(
      "POST",
      "/orders/$orderId/items/$itemId/availability-choice",
      body: {"choice": choice, if (productId != null) "productId": productId},
    );
    await Future.wait([loadOrders(), loadActiveOrder(), loadCustomerCredit()]);
  }

  AppState._() {
    realtime.onEvent = _handleRealtimeEvent;
    api.onAccessTokenChanged = (freshToken) {
      if (freshToken == null) {
        realtime.disconnect();
      } else if (user != null) {
        realtime.reconnect(freshToken);
      }
    };
  }

  static final instance = AppState._();
  final api = ApiClient.instance;
  final realtime = RealtimeClient.instance;

  Map<String, dynamic>? user;
  List<dynamic> products = [];
  List<dynamic> catalogCategories = [];
  List<dynamic> addresses = [];
  List<dynamic> orders = [];
  Map<String, dynamic>? activeOrder;
  Map<String, dynamic>? courierDelivery;
  List<dynamic> courierOffers = [];
  int _courierOperationsEpoch = 0;
  Future<void>? _courierOperationsFuture;
  Future<void>? _deliveryAction;
  bool courierOnline = false;
  bool _courierOnlineAuthorizedThisSession = false;
  bool courierHighDemand = false;
  double courierDemandBonus = 0;
  bool publicHighDemand = false;
  int _publicDemandRevision = -1;
  int _courierDemandRevision = -1;
  String courierPresenceStatus = 'OFFLINE';
  Map<String, dynamic> walletSummary = {};
  List<dynamic> walletLedger = [];
  List<dynamic> withdrawals = [];
  List<dynamic> courierHistory = [];
  Map<String, dynamic> courierProfile = {};
  Map<String, dynamic> deliveryQuote = {};
  final Map<String, int> cart = {};
  bool loading = false;
  bool storeOpen = false;
  bool storeStatusKnown = false;
  DateTime? _storeUpdatedAt;
  String storeMessage = "Voltaremos em breve. Sua sacola continua salva.";
  bool _catalogRefreshRunning = false;
  bool _catalogRefreshAgain = false;
  String? error;
  String catalogCategory = 'Todos';
  bool _catalogPolling = false;

  bool get loggedIn => user != null;
  bool get isCustomer => user?['role'] == 'CUSTOMER';
  bool get isPartner => user?['role'] == 'PARTNER';
  bool get isCourier => user?['role'] == 'COURIER';
  int get cartCount => cart.values.fold(0, (a, b) => a + b);
  double get cartSubtotal => cart.entries.fold(0, (sum, e) {
    final p = product(e.key);
    return sum +
        (p == null
            ? 0
            : (double.tryParse(p['price'].toString()) ?? 0) * e.value);
  });

  Future<void> bootstrap() async {
    await PartnerReferral.capture(api);
    realtime.connectCatalog();
    await loadProducts();
    startCatalogSync();

    if (api.token != null || api.refreshToken != null) {
      _courierOnlineAuthorizedThisSession = false;
      try {
        final me = await api.request('GET', '/auth/me');
        user = Map<String, dynamic>.from(me as Map);
        if (api.token != null) realtime.connect(api.token!);
      } catch (_) {
        await api.clearSession();
        user = null;
        customerCreditBalance = 0;
        customerCreditCard = {};
        useCustomerCredit = false;
        customerCreditRequested = 0;
      }
    }

    if (loggedIn && isCustomer) {
      await Future.wait([loadAddresses(), loadOrders(), loadActiveOrder()]);
    }
    if (loggedIn && isPartner) await loadWallet();
    if (loggedIn && isCourier) {
      await refreshCourier();
    }
    notifyListeners();
  }

  int supportEpoch = 0;
  int deliveryChatEpoch = 0;
  final Set<String> _deliveryChatSeen = {};
  Map<String, dynamic>? incomingDeliveryChat;
  int deliveryPricingEpoch = 0;
  int _quoteGeneration = 0;

  void _handleRealtimeEvent(String event, dynamic payload) {
    if (event == 'delivery.chat.updated' &&
        payload is Map &&
        loggedIn &&
        (isCustomer || isCourier)) {
      final incoming = Map<String, dynamic>.from(payload);
      if (incoming['recipientId'] == (user?['id']) &&
          incoming['senderId'] != (user?['id']) &&
          incoming['orderId'] is String &&
          incoming['messageId'] is String) {
        if (_deliveryChatSeen.add(incoming['messageId'] as String)) {
          if (_deliveryChatSeen.length > 500)
            _deliveryChatSeen.remove(_deliveryChatSeen.first);
          incomingDeliveryChat = incoming;
          deliveryChatEpoch++;
        }
      }
    }
    if (event == 'support.updated' ||
        event == 'delivery.chat.updated' ||
        event == 'session.ready') {
      supportEpoch++;
      notifyListeners();
      if (event == 'support.updated' || event == 'delivery.chat.updated')
        return;
    }
    if (event == 'demand.updated' && payload is Map) {
      _applyPublicDemand(Map<String, dynamic>.from(payload));
      return;
    }
    if (event == 'courier.demand.updated' && isCourier && payload is Map) {
      _applyCourierDemand(Map<String, dynamic>.from(payload));
      return;
    }
    if (event == 'delivery.pricing.updated') {
      _quoteGeneration++;
      deliveryQuote = {};
      deliveryPricingEpoch++;
      notifyListeners();
      if (isCustomer) loadAddresses().catchError((_) {});
      return;
    }
    if (event == 'addresses.updated' && isCustomer) {
      deliveryPricingEpoch++;
      deliveryQuote = {};
      _quoteGeneration++;
      notifyListeners();
      loadAddresses().catchError((_) {});
      return;
    }
    if (event == 'store.updated') {
      if (payload is Map && payload['storeOpen'] is bool)
        _applyStore(Map<String, dynamic>.from(payload));
      loadStore().catchError((_) {});
      return;
    }
    if (event == 'catalog.updated') {
      loadProducts(silent: true);
      return;
    }
    if (event == 'session.revoked') {
      unawaited(CourierRouteTracker.instance.stop());
      Future<void>(() async {
        realtime.disconnect();
        await api.clearSession();
        user = null;
        customerCreditBalance = 0;
        customerCreditCard = {};
        useCustomerCredit = false;
        customerCreditRequested = 0;
        addresses = [];
        orders = [];
        activeOrder = null;
        courierDelivery = null;
        courierOffers = [];
        _courierOperationsEpoch++;
        courierOnline = false;
        courierHighDemand = false;
        _courierDemandRevision = -1;
        courierPresenceStatus = 'OFFLINE';
        walletSummary = {};
        walletLedger = [];
        withdrawals = [];
        courierHistory = [];
        courierProfile = {};
        deliveryQuote = {};
        cart.clear();
        notifyListeners();
      });
      return;
    }

    if (!loggedIn) return;
    if (isCourier && event == 'transport.disconnected') {
      ++_courierOperationsEpoch;
      courierOnline = false;
      courierOffers = [];
      notifyListeners();
      return;
    }
    if (event == 'delivery.location.updated') {
      DeliveryLocationFeed.instance.receive(payload);
      return;
    }

    if (event == 'order.deleted' && payload is Map) {
      final id = payload['orderId']?.toString();
      if (id != null) removedOrderIds.add(id);
      orders.removeWhere((o) => o['id'].toString() == id);
      if (activeOrder?['id'].toString() == id) activeOrder = null;
      if (courierDelivery?['id'].toString() == id) {
        courierDelivery = null;
        unawaited(CourierRouteTracker.instance.stop());
      }
      courierHistory.removeWhere((o) => o['id'].toString() == id);
      courierOffers.removeWhere((o) => o['orderId']?.toString() == id);
      if (isCourier) unawaited(CourierOfferAlerts.dismiss().catchError((_) {}));
      notifyListeners();
    }

    if ((isCustomer && event == 'customer.profile.updated') ||
        (isPartner && event == 'partner.profile.updated')) {
      Future<void>(() async {
        try {
          user = Map<String, dynamic>.from(
            await api.request('GET', '/auth/me'),
          );
          notifyListeners();
        } catch (_) {}
      });
      return;
    }
    if (isCustomer &&
        (event == 'order.deleted' ||
            event == 'order.updated' ||
            event == 'order.created' ||
            event == 'customer.credit.updated')) {
      Future<void>(() async {
        try {
          await Future.wait([loadOrders(), loadActiveOrder()]);
        } catch (_) {}
      });
      return;
    }

    if (isCourier &&
        !courierRestricted &&
        courierOnline &&
        event == 'delivery.offer' &&
        payload is Map) {
      final offer = Map<String, dynamic>.from(payload);
      final expiry = DateTime.tryParse(offer['expiresAt']?.toString() ?? '');
      if (offer['offerId'] != null &&
          expiry != null &&
          expiry.isAfter(DateTime.now()) &&
          courierDelivery == null) {
        _courierOperationsEpoch++;
        courierOffers = [offer];
        notifyListeners();
        unawaited(CourierOfferAlerts.show(offer).catchError((_) {}));
      }
      // The authenticated socket already contains the complete safe offer.
      return;
    }
    if (isCourier && event == 'delivery.offer.closed' && payload is Map) {
      _courierOperationsEpoch++;
      final orderId = payload['orderId']?.toString(),
          offerId = payload['offerId']?.toString();
      courierOffers.removeWhere(
        (offer) => offerId != null
            ? offer['offerId']?.toString() == offerId
            : offer['orderId']?.toString() == orderId,
      );
      unawaited(CourierOfferAlerts.dismiss(offerId).catchError((_) {}));
      notifyListeners();
      return;
    }
    if (isCourier && event == 'session.ready') {
      unawaited(refreshCourier().catchError((_) {}));
      return;
    }
    if (isCourier &&
        (event == 'session.ready' ||
            event == 'delivery.accepted' ||
            event == 'order.deleted' ||
            event == 'order.updated' ||
            event == 'courier.presence')) {
      unawaited(refreshCourierOperations().catchError((_) {}));
      return;
    }

    if (isCourier &&
        event == 'courier.requirements.updated' &&
        payload is Map) {
      // Display Admin instructions immediately, without waiting for the
      // network round-trip to /couriers/application/me. Only the authenticated
      // user's socket receives these safe fields from the backend.
      final targetId = payload['courierId']?.toString();
      final currentId = courierProfile['id']?.toString();
      if (targetId != null && currentId != null && targetId != currentId)
        return;

      final instructions = payload['requirements'];
      if (instructions is List) {
        final snapshot = Map<String, dynamic>.from(courierProfile);
        snapshot['requirements'] = instructions
            .whereType<Map>()
            .map((item) => Map<String, dynamic>.from(item))
            .toList();
        if (payload['approvalStatus'] is String) {
          snapshot['approvalStatus'] = payload['approvalStatus'];
        }
        courierProfile = snapshot;
      }
      if (payload['userStatus'] is String && user != null) {
        final next = Map<String, dynamic>.from(user!);
        next['status'] = payload['userStatus'];
        user = next;
      }
      // Reject any older profile fetch already in flight; otherwise a stale
      // result could overwrite the newest Admin request on the next frame.
      ++_courierAccountEpoch;
      if (courierRestricted) {
        ++_courierOperationsEpoch;
        courierOnline = false;
        courierPresenceStatus = 'OFFLINE';
        courierOffers = [];
        unawaited(CourierOfferAlerts.offline().catchError((_) {}));
      }
      notifyListeners();
      unawaited(refreshCourierAccount().catchError((_) {}));
      return;
    }

    if (isCourier && event == 'courier.profile.updated') {
      Future<void>(() async {
        try {
          await refreshCourierAccount();
          if (!courierRestricted) await refreshCourierOperations();
        } catch (_) {}
      });
      return;
    }

    if ((isCourier || isPartner) && event == 'wallet.updated') {
      Future<void>(() async {
        try {
          await loadWallet();
        } catch (_) {}
      });
    }
  }

  void startCatalogSync() {
    if (_catalogPolling) return;
    _catalogPolling = true;
    Future<void>(() async {
      while (_catalogPolling) {
        await Future<void>.delayed(const Duration(seconds: 30));
        try {
          await loadProducts(silent: true);
        } catch (_) {}
      }
    });
  }

  bool _sameCatalog(List<dynamic> a, List<dynamic> b) {
    if (identical(a, b)) return true;
    if (a.length != b.length) return false;
    for (var i = 0; i < a.length; i++) {
      final left = a[i] as Map?;
      final right = b[i] as Map?;
      if (left == null || right == null) return false;
      for (final key in const [
        'id',
        'name',
        'price',
        'stock',
        'active',
        'imageUrl',
        'description',
        'position',
        'updatedAt',
      ]) {
        if (left[key]?.toString() != right[key]?.toString()) return false;
      }
      final leftCategory = left['category'] as Map?;
      final rightCategory = right['category'] as Map?;
      for (final key in const [
        'id',
        'name',
        'imageUrl',
        'position',
        'active',
        'updatedAt',
      ]) {
        if (leftCategory?[key]?.toString() != rightCategory?[key]?.toString())
          return false;
      }
    }
    return true;
  }

  void _applyStore(Map<String, dynamic> store) {
    final updated = DateTime.tryParse(store['updatedAt']?.toString() ?? '');
    if (updated != null &&
        _storeUpdatedAt != null &&
        updated.isBefore(_storeUpdatedAt!))
      return;
    final nextOpen = store['storeOpen'] == true;
    final message = store['storeMessage']?.toString() ?? storeMessage;
    final changed =
        !storeStatusKnown || storeOpen != nextOpen || storeMessage != message;
    storeOpen = nextOpen;
    storeMessage = message;
    storeStatusKnown = true;
    if (updated != null) _storeUpdatedAt = updated;
    if (changed) notifyListeners();
  }

  Future<void> loadStore() async {
    final result = await api.request('GET', '/products/store');
    _applyStore(Map<String, dynamic>.from(result as Map));
  }

  Future<void> loadProducts({bool silent = false}) async {
    loadPublicDemand().catchError((_) {});
    if (_catalogRefreshRunning) {
      _catalogRefreshAgain = true;
      return;
    }
    _catalogRefreshRunning = true;
    try {
      do {
        _catalogRefreshAgain = false;
        final values = await Future.wait([
          api.request('GET', '/products'),
          loadStore(),
          api.request('GET', '/products/categories'),
        ]);
        final next = List<dynamic>.from(values[0]);
        final nextCategories = List<dynamic>.from(values[2]);
        final changed =
            !_sameCatalog(next, products) ||
            !_sameCatalog(nextCategories, catalogCategories);
        products = next;
        catalogCategories = nextCategories;
        if (catalogCategory != 'Todos' &&
            !nextCategories.any((c) => c['name'] == catalogCategory))
          catalogCategory = 'Todos';
        if (changed) notifyListeners();
      } while (_catalogRefreshAgain);
    } catch (e) {
      if (!silent) {
        error = e.toString();
        notifyListeners();
      }
    } finally {
      _catalogRefreshRunning = false;
    }
  }

  Future<Map<String, dynamic>> lookupPostalCode(String cep) async {
    final q = Uri(queryParameters: {'cep': cep}).query;
    return Map<String, dynamic>.from(
      await api.request('GET', '/auth/postal-code?$q'),
    );
  }

  Future<Map<String, dynamic>> checkAvailability(
    String field,
    String value,
  ) async {
    final q = Uri(queryParameters: {'field': field, 'value': value}).query;
    return Map<String, dynamic>.from(
      await api.request('GET', '/auth/availability?$q'),
    );
  }

  Future<Map<String, dynamic>> lookupCourierCpf(
    String cpf,
    String birthDate,
  ) async {
    return Map<String, dynamic>.from(
      await api.request(
        'POST',
        '/auth/courier-cpf',
        body: {'cpf': cpf, 'birthDate': birthDate},
        timeout: const Duration(seconds: 70),
        retryOnUnauthorized: false,
      ),
    );
  }

  Future<Map<String, dynamic>> courierApplicationStatus(String document) async {
    return Map<String, dynamic>.from(
      await api.request(
        'POST',
        '/couriers/application/status',
        body: {'document': document.replaceAll(RegExp(r'\D'), '')},
        retryOnUnauthorized: false,
      ),
    );
  }

  Future<Map<String, dynamic>> respondCourierApplicationRequirement(
    String requirementId,
    String document,
    String response,
  ) async {
    return Map<String, dynamic>.from(
      await api.request(
        'POST',
        '/couriers/application/requirements/' + requirementId + '/respond',
        body: {'document': document, 'response': response},
      ),
    );
  }

  Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
    required String phone,
    required String role,
    String? businessName,
    String? document,
    Map<String, dynamic>? profileData,
  }) async {
    final d = <String, dynamic>{
      'name': name,
      'email': email,
      'password': password,
      'phone': phone,
      'role': role,
      if (businessName != null && businessName.trim().isNotEmpty)
        'businessName': businessName,
      if (document != null && document.trim().isNotEmpty) 'document': document,
      if (profileData != null) 'profileData': profileData,
      if (role == 'COURIER' && profileData != null) ...{
        if ((profileData['cnh'] ?? '').toString().trim().isNotEmpty)
          'cnh': profileData['cnh'].toString().trim(),
        if ((profileData['cnhCategory'] ?? '').toString().trim().isNotEmpty)
          'cnhCategory': profileData['cnhCategory'].toString().trim(),
        if ((profileData['vehicleBrand'] ?? '').toString().trim().isNotEmpty)
          'vehicleBrand': profileData['vehicleBrand'].toString().trim(),
        if ((profileData['vehicleModel'] ?? '').toString().trim().isNotEmpty)
          'vehicleModel': profileData['vehicleModel'].toString().trim(),
        if ((profileData['vehiclePlate'] ?? '').toString().trim().isNotEmpty)
          'vehiclePlate': profileData['vehiclePlate'].toString().trim(),
        if (int.tryParse((profileData['vehicleYear'] ?? '').toString()) != null)
          'vehicleYear': int.parse(profileData['vehicleYear'].toString()),
      },
    };
    loading = true;
    error = null;
    notifyListeners();
    try {
      final created = Map<String, dynamic>.from(
        await api.request(
          'POST',
          '/auth/register',
          body: d,
          timeout: role == 'COURIER' ? const Duration(seconds: 75) : null,
        ),
      );
      if (role == 'CUSTOMER') {
        return await login(email, password);
      }
      // Motoboy e parceiro aguardam aprovação: não criamos sessão local.
      user = null;
      customerCreditBalance = 0;
      customerCreditCard = {};
      useCustomerCredit = false;
      customerCreditRequested = 0;
      await api.clearSession();
      realtime.disconnect();
      return created;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
      rethrow;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>> forgotPassword(String email) async =>
      Map<String, dynamic>.from(
        await api.request(
          'POST',
          '/auth/forgot-password',
          body: {'email': email.trim()},
        ),
      );
  Future<void> resetPassword(String token, String password) async {
    await api.request(
      'POST',
      '/auth/reset-password',
      body: {'token': token, 'password': password},
    );
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    _courierOnlineAuthorizedThisSession = false;
    loading = true;
    error = null;
    notifyListeners();
    try {
      final x = Map<String, dynamic>.from(
        await api.request(
          'POST',
          '/auth/login',
          body: {'email': email.trim(), 'password': password},
        ),
      );
      await api.setSession(x);
      user = Map<String, dynamic>.from(x['user']);
      if (api.token != null) realtime.connect(api.token!);
      try {
        if (isCustomer) {
          await Future.wait([loadAddresses(), loadOrders(), loadActiveOrder()]);
        }
        if (isPartner) await loadWallet();
        if (isCourier) {
          await refreshCourier();
        }
      } catch (_) {
        error = "Você entrou. Não foi possível atualizar todos os dados agora. Tente atualizar o painel.";
      }
      return x;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
      rethrow;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    try {
      await api.request('POST', '/auth/logout');
    } catch (_) {}
    await CourierRouteTracker.instance.stop();
    await CourierOfferAlerts.offline().catchError((_) {});
    realtime.disconnect();
    await api.clearSession();
    user = null;
    customerCreditBalance = 0;
    customerCreditCard = {};
    useCustomerCredit = false;
    customerCreditRequested = 0;
    addresses = [];
    orders = [];
    activeOrder = null;
    courierDelivery = null;
    courierOffers = [];
    _courierOperationsEpoch++;
    courierHighDemand = false;
    _courierDemandRevision = -1;
    courierOnline = false;
    courierPresenceStatus = 'OFFLINE';
    walletSummary = {};
    walletLedger = [];
    withdrawals = [];
    courierHistory = [];
    courierProfile = {};
    deliveryQuote = {};
    cart.clear();
    error = null;
    notifyListeners();
  }

  int stockLimit(String id) {
    final item = product(id);
    if (item == null ||
        item['active'] == false ||
        item['archived'] == true ||
        item['category']?['active'] == false ||
        item['category']?['archived'] == true)
      return 0;
    final stock = int.tryParse('${item['stock']}') ?? 0;
    return stock < 0 ? 0 : stock;
  }

  bool canIncreaseQuantity(String id) =>
      storeStatusKnown && storeOpen && (cart[id] ?? 0) < stockLimit(id);
  bool get cartExceedsStock =>
      cart.entries.any((entry) => entry.value > stockLimit(entry.key));
  void addProduct(String id) {
    if (!canIncreaseQuantity(id)) return;
    cart[id] = (cart[id] ?? 0) + 1;
    notifyListeners();
  }

  void changeQty(String id, int d) {
    final n = (cart[id] ?? 0) + d;
    if (d > 0 && (!canIncreaseQuantity(id) || n > stockLimit(id))) return;
    if (n <= 0)
      cart.remove(id);
    else
      cart[id] = n;
    if (cart.isEmpty) {
      useCustomerCredit = false;
      customerCreditRequested = 0;
    }
    notifyListeners();
  }

  void removeProduct(String id) {
    cart.remove(id);
    if (cart.isEmpty) {
      useCustomerCredit = false;
      customerCreditRequested = 0;
    }
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    useCustomerCredit = false;
    customerCreditRequested = 0;
    notifyListeners();
  }

  void selectCatalogCategory(String name) {
    catalogCategory = name;
    notifyListeners();
  }

  dynamic product(String id) {
    for (final p in products) {
      if (p['id'] == id) return p;
    }
    return null;
  }

  Future<void> loadAddresses() async {
    if (!isCustomer) return;
    addresses = List<dynamic>.from(await api.request('GET', '/addresses'));
    if (addresses.isNotEmpty) {
      final selected = addresses.firstWhere(
        (a) => a['isDefault'] == true,
        orElse: () => addresses.first,
      );
      try {
        await quoteDelivery(selected['id'].toString());
      } catch (_) {
        deliveryQuote = {};
      }
    } else {
      deliveryQuote = {};
    }
    notifyListeners();
  }

  Future<void> addAddress(Map<String, dynamic> d) async {
    await api.request('POST', '/addresses', body: d);
    await loadAddresses();
  }

  Future<void> updateAddress(String id, Map<String, dynamic> d) async {
    await api.request('PATCH', '/addresses/$id', body: d);
    await loadAddresses();
  }

  Future<void> removeAddress(String id) async {
    await api.request('DELETE', '/addresses/$id');
    await loadAddresses();
  }

  Future<int> clearPendingOrders() async {
    if (!isCustomer) return 0;
    final x = Map<String, dynamic>.from(
      await api.request('DELETE', '/orders/pending'),
    );
    await Future.wait([loadOrders(), loadActiveOrder()]);
    return (x['deleted'] as num?)?.toInt() ?? 0;
  }

  Future<void> loadOrders() async {
    if (!isCustomer) return;
    final customerId = user?['id'];
    final result = await api.request('GET', '/orders/mine');
    if (!isCustomer || user?['id'] != customerId) return;
    orders = List<dynamic>.from(result)
        .where(
          (o) =>
              o is Map &&
              const [
                'PAID',
                'PARTIALLY_REFUNDED',
                'REFUNDED',
              ].contains(o['paymentStatus']),
        )
        .toList();
    try {
      await loadCustomerCredit();
    } catch (_) {}
    if (isCustomer && user?['id'] == customerId) notifyListeners();
  }

  Future<void> loadActiveOrder() async {
    if (!isCustomer) return;
    final customerId = user?['id'];
    final x = await api.request('GET', '/orders/active');
    if (!isCustomer || user?['id'] != customerId) return;
    activeOrder =
        x == null ||
            !const [
              'PAID',
              'PARTIALLY_REFUNDED',
              'REFUNDED',
            ].contains(x['paymentStatus'])
        ? null
        : Map<String, dynamic>.from(x);
    notifyListeners();
  }

  Future<void>? _courierRefreshFuture;

  Future<void> refreshCourier() {
    final running = _courierRefreshFuture;
    if (running != null) return running;

    final future = _refreshCourierOnce();
    _courierRefreshFuture = future;
    void clearRunning() {
      if (identical(_courierRefreshFuture, future)) {
        _courierRefreshFuture = null;
      }
    }

    future.then((_) => clearRunning(), onError: (Object _) => clearRunning());
    return future;
  }

  /// Only delivery-critical data. Wallet/history/profile never block an offer.
  Future<void> refreshCourierOperations() {
    final running = _courierOperationsFuture;
    if (running != null) return running;
    final future = _loadCourierOperationsOnce();
    _courierOperationsFuture = future;
    void clear() {
      if (identical(_courierOperationsFuture, future))
        _courierOperationsFuture = null;
    }

    future.then<void>(
      (_) => clear(),
      onError: (Object _, StackTrace __) => clear(),
    );
    return future;
  }

  Future<void> _loadCourierOperationsOnce() async {
    if (!isCourier || courierRestricted) return;
    final accountId = user?['id'];
    final epoch = ++_courierOperationsEpoch;
    final results = await Future.wait([
      api.request('GET', '/orders/courier/presence'),
      api.request('GET', '/orders/courier/current'),
      api.request('GET', '/orders/courier/available'),
    ]);
    if (!isCourier ||
        user?['id'] != accountId ||
        epoch != _courierOperationsEpoch)
      return;
    final presence = Map<String, dynamic>.from(results[0] as Map);
    courierPresenceStatus = (presence['presenceStatus'] ?? 'OFFLINE')
        .toString();
    final serverOnline = presence['isOnline'] == true;
    courierOnline = serverOnline && _courierOnlineAuthorizedThisSession;
    if (serverOnline && !courierOnline) {
      courierPresenceStatus = 'OFFLINE';
      unawaited(
        api
            .request('PATCH', '/orders/courier/online', body: {'online': false})
            .catchError((_) {}),
      );
    }
    courierDelivery = results[1] == null
        ? null
        : Map<String, dynamic>.from(results[1] as Map);
    courierOffers = List<dynamic>.from(results[2] as List);
    if (!courierOnline) courierOffers = [];
    if (courierOnline) {
      unawaited(CourierOfferAlerts.online().catchError((_) {}));
      final offer = courierOffers
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .firstOrNull;
      if (offer != null)
        unawaited(CourierOfferAlerts.show(offer).catchError((_) {}));
      else
        unawaited(CourierOfferAlerts.dismiss().catchError((_) {}));
    } else {
      unawaited(CourierOfferAlerts.offline().catchError((_) {}));
    }
    unawaited(CourierRouteTracker.instance.sync(courierDelivery));
    notifyListeners();
  }

  bool get courierRestricted =>
      isCourier &&
      (user?['status'] != 'ACTIVE' ||
          (courierProfile.isNotEmpty &&
              courierProfile['approvalStatus'] != 'APPROVED'));

  int _courierAccountEpoch = 0;
  Future<void> refreshCourierAccount() async {
    if (!isCourier) return;
    final accountId = user?['id'];
    final epoch = ++_courierAccountEpoch;
    final results = await Future.wait([
      api.request('GET', '/auth/me'),
      api.request('GET', '/couriers/application/me'),
    ]);
    if (!isCourier || user?['id'] != accountId || epoch != _courierAccountEpoch)
      return;
    user = Map<String, dynamic>.from(results[0] as Map);
    courierProfile = Map<String, dynamic>.from(results[1] as Map);
    if (courierRestricted) {
      ++_courierOperationsEpoch;
      courierOnline = false;
      courierPresenceStatus = 'OFFLINE';
      courierOffers = [];
      unawaited(CourierOfferAlerts.offline().catchError((_) {}));
    }
    notifyListeners();
  }

  Future<void> _refreshCourierOnce() async {
    if (!isCourier) return;
    final accountId = user?['id'];
    await refreshCourierAccount();
    if (courierRestricted || !isCourier || user?['id'] != accountId) return;
    unawaited(loadCourierDemand().catchError((_) {}));
    await refreshCourierOperations();
    await Future.wait<void>([
      api
          .request('GET', '/wallet/summary')
          .then<void>((data) {
            if (isCourier && user?['id'] == accountId) {
              walletSummary = Map<String, dynamic>.from(data as Map);
              notifyListeners();
            }
          })
          .catchError((_) {}),
      api
          .request('GET', '/orders/courier/history')
          .then<void>((data) {
            if (isCourier && user?['id'] == accountId) {
              courierHistory = List<dynamic>.from(data as List);
              notifyListeners();
            }
          })
          .catchError((_) {}),
    ]);
  }

  void _applyCourierDemand(Map<String, dynamic> data) {
    final revision = data['revision'];
    if (data['enabled'] is! bool ||
        revision is! int ||
        revision < _courierDemandRevision)
      return;
    _courierDemandRevision = revision;
    final next = data['enabled'] == true;
    final bonus = double.tryParse(data['bonusAmount'].toString()) ?? 0;
    if (courierHighDemand != next || courierDemandBonus != bonus) {
      courierHighDemand = next;
      courierDemandBonus = bonus;
      notifyListeners();
    }
  }

  void _applyPublicDemand(Map<String, dynamic> data) {
    final revision = data['revision'];
    if (data['enabled'] is! bool ||
        revision is! int ||
        revision < _publicDemandRevision)
      return;
    _publicDemandRevision = revision;
    final next = data['enabled'] == true;
    if (publicHighDemand != next) {
      publicHighDemand = next;
      notifyListeners();
    }
  }

  Future<void> loadPublicDemand() async {
    final data = await api.request('GET', '/operations/demand');
    if (data is Map) _applyPublicDemand(Map<String, dynamic>.from(data));
  }

  Future<void> loadCourierDemand() async {
    if (!isCourier) return;
    final requestedUser = user?['id'];
    final result = await api.request('GET', '/couriers/operations/demand');
    if (isCourier && user?['id'] == requestedUser && result is Map) {
      _applyCourierDemand(Map<String, dynamic>.from(result));
    }
  }

  Future<void> heartbeatCourier({double? latitude, double? longitude}) async {
    if (!isCourier || courierRestricted) return;
    final accountId = user?['id'];
    final availabilityEpoch = _courierOperationsEpoch;
    final result = Map<String, dynamic>.from(
      await api.request(
        'PATCH',
        '/orders/courier/heartbeat',
        body: {
          if (latitude != null) 'latitude': latitude,
          if (longitude != null) 'longitude': longitude,
        },
      ),
    );
    if (!isCourier ||
        user?['id'] != accountId ||
        courierRestricted ||
        availabilityEpoch != _courierOperationsEpoch)
      return;
    final nextPresence = (result['presenceStatus'] ?? 'OFFLINE').toString();
    final nextOnline = result['isOnline'] == true;
    final changed =
        nextPresence != courierPresenceStatus || nextOnline != courierOnline;
    courierPresenceStatus = nextPresence;
    courierOnline = nextOnline;
    if (changed) {
      if (nextOnline)
        unawaited(CourierOfferAlerts.online().catchError((_) {}));
      else
        unawaited(CourierOfferAlerts.offline().catchError((_) {}));
      notifyListeners();
    }
  }

  Future<void> setCourierOnline(bool online) async {
    final accountId = user?['id'];
    if (!isCourier || courierRestricted) return;
    if (online) {
      if (!await Geolocator.isLocationServiceEnabled()) {
        await Geolocator.openLocationSettings();
        return;
      }
      var locationPermission = await Geolocator.checkPermission();
      if (locationPermission == LocationPermission.denied) {
        locationPermission = await Geolocator.requestPermission();
      }
      if (locationPermission == LocationPermission.deniedForever) {
        await Geolocator.openAppSettings();
        return;
      }
      if (locationPermission != LocationPermission.whileInUse &&
          locationPermission != LocationPermission.always) {
        return;
      }
      if (!await CourierOfferAlerts.prepareOnline()) return;
    }
    if (!isCourier || user?['id'] != accountId || courierRestricted) return;
    ++_courierOperationsEpoch;
    final result = Map<String, dynamic>.from(
      await api.request(
        'PATCH',
        '/orders/courier/online',
        body: {'online': online},
      ),
    );
    if (!isCourier || user?['id'] != accountId || courierRestricted) return;
    courierPresenceStatus = (result['presenceStatus'] ?? 'OFFLINE').toString();
    courierOnline = result['isOnline'] == true;
    _courierOnlineAuthorizedThisSession = online && courierOnline;
    if (courierOnline)
      unawaited(CourierOfferAlerts.online().catchError((_) {}));
    else
      unawaited(CourierOfferAlerts.offline().catchError((_) {}));
    notifyListeners();
    unawaited(refreshCourierOperations().catchError((_) {}));
  }

  Future<void> acceptDelivery(String id) async {
    if (_deliveryAction != null) return _deliveryAction!;
    final action = _acceptDeliveryOnce(id);
    _deliveryAction = action;
    try {
      await action;
    } finally {
      if (identical(_deliveryAction, action)) _deliveryAction = null;
    }
  }

  Future<void> _acceptDeliveryOnce(String id) async {
    final accountId = user?['id'];
    _courierOperationsEpoch++;
    dynamic result;
    try {
      result = await api.request('PATCH', '/orders/$id/courier/accept');
    } catch (_) {
      // A lost response must not report failure if the socket confirmed it.
      if (isCourier &&
          user?['id'] == accountId &&
          courierDelivery?['id']?.toString() == id)
        return;
      unawaited(refreshCourierOperations().catchError((_) {}));
      rethrow;
    }
    if (!isCourier || user?['id'] != accountId) return;
    _courierOperationsEpoch++;
    courierDelivery = Map<String, dynamic>.from(result as Map);
    courierOffers.removeWhere((offer) => offer['orderId']?.toString() == id);
    unawaited(CourierOfferAlerts.dismiss().catchError((_) {}));
    courierPresenceStatus = 'DELIVERING';
    notifyListeners();
    unawaited(CourierRouteTracker.instance.sync(courierDelivery));
    unawaited(refreshCourierOperations().catchError((_) {}));
  }

  Future<void> rejectDelivery(String id) async {
    _courierOperationsEpoch++;
    await api.request('PATCH', '/orders/$id/courier/reject');
    _courierOperationsEpoch++;
    courierOffers.removeWhere((offer) => offer['orderId']?.toString() == id);
    unawaited(CourierOfferAlerts.dismiss().catchError((_) {}));
    notifyListeners();
    unawaited(refreshCourierOperations().catchError((_) {}));
  }

  Future<void> advanceDelivery(String id, String status, {String? pin}) async {
    courierDelivery = Map<String, dynamic>.from(
      await api.request(
        'PATCH',
        '/orders/$id/courier/status',
        body: {
          'status': status,
          if (pin != null && pin.trim().isNotEmpty) 'pin': pin.trim(),
        },
      ),
    );
    // Tracking starts only after the existing status request succeeds.
    unawaited(
      CourierRouteTracker.instance.sync(
        courierDelivery,
        requestPermission: status == 'OUT_FOR_DELIVERY',
      ),
    );
    if (status == 'DELIVERED') {
      courierPresenceStatus = 'AVAILABLE';
      await loadWallet();
    } else {
      courierPresenceStatus = 'DELIVERING';
    }
    await refreshCourier();
  }

  Future<void> loadWallet() async {
    if (isPartner) {
      final data = Map<String, dynamic>.from(
        await api.request('GET', '/finance/me'),
      );
      walletSummary = data;
      walletLedger = List<dynamic>.from(data['entries'] ?? []);
      withdrawals = List<dynamic>.from(data['withdrawals'] ?? []);
      notifyListeners();
      return;
    }
    if (!isCourier) return;
    final result = await Future.wait([
      api.request('GET', '/wallet/summary'),
      api.request('GET', '/wallet/ledger?take=100'),
      api.request('GET', '/wallet/withdrawals'),
    ]);
    walletSummary = Map<String, dynamic>.from(result[0] as Map);
    walletLedger = List<dynamic>.from(result[1] as List);
    withdrawals = List<dynamic>.from(result[2] as List);
    notifyListeners();
  }

  String newFinanceRequestId() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    bytes[6] = (bytes[6] & 15) | 64;
    bytes[8] = (bytes[8] & 63) | 128;
    final h = bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    return '${h.substring(0, 8)}-${h.substring(8, 12)}-${h.substring(12, 16)}-${h.substring(16, 20)}-${h.substring(20)}';
  }

  Future<Map<String, dynamic>> requestWithdrawal(
    double amount, {
    String? pixKey,
    String? pixKeyType,
    String? requestId,
  }) async {
    final created = Map<String, dynamic>.from(
      await api.request(
        'POST',
        isPartner ? '/finance/me/withdrawals' : '/wallet/withdrawals',
        body: {
          'amount': amount,
          'requestId': requestId ?? newFinanceRequestId(),
          if (pixKey != null) 'pixKey': pixKey,
          if (pixKeyType != null) 'pixKeyType': pixKeyType,
        },
      ),
    );
    await loadWallet();
    return created;
  }

  Future<Map<String, dynamic>> quoteDelivery(String addressId) async {
    final generation = ++_quoteGeneration;
    final query = Uri(queryParameters: {'addressId': addressId}).query;
    final quote = Map<String, dynamic>.from(
      await api.request('GET', '/delivery/quote?$query'),
    );
    if (generation == _quoteGeneration) {
      deliveryQuote = quote;
      notifyListeners();
    }
    return quote;
  }

  Future<Map<String, dynamic>> createOrder(
    String addressId, {
    int? pricingRevision,
    double? expectedDeliveryFee,
    double? expectedTotal,
    double storeCreditRequested = 0,
  }) async {
    if (!isCustomer) throw Exception('Entre como cliente para finalizar');
    if (cart.isEmpty) throw Exception('Sua sacola está vazia');
    await loadStore();
    if (!storeOpen) throw Exception(storeMessage);
    loading = true;
    error = null;
    notifyListeners();
    try {
      final order = Map<String, dynamic>.from(
        await api.request(
          'POST',
          '/orders',
          body: {
            'addressId': addressId,
            if (PartnerReferral.code != null)
              'referralCode': PartnerReferral.code,
            'storeCreditRequested': storeCreditRequested,
            if (expectedTotal != null) 'expectedTotal': expectedTotal,
            if (pricingRevision != null) 'pricingRevision': pricingRevision,
            if (expectedDeliveryFee != null)
              'expectedDeliveryFee': expectedDeliveryFee,
            'items': cart.entries
                .map((e) => {'productId': e.key, 'quantity': e.value})
                .toList(),
          },
        ),
      );
      await Future.wait([loadOrders(), loadActiveOrder()]);
      return order;
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
      rethrow;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>> createCheckout(String orderId) async {
    await loadStore();
    if (!storeOpen) throw Exception(storeMessage);
    loading = true;
    error = null;
    notifyListeners();
    try {
      // Native apps have a file URI, not a browser origin. These compatibility
      // URLs are validated by the API; native payment uses PaymentSheet.
      final origin = kIsWeb ? Uri.base.origin : Uri.parse(api.baseUrl).origin;
      return Map<String, dynamic>.from(
        await api.request(
          'POST',
          '/payments/checkout',
          body: {
            'orderId': orderId,
            'successUrl':
                '$origin/checkout-return?checkout=success&orderId=$orderId',
            'cancelUrl':
                '$origin/checkout-return?checkout=cancel&orderId=$orderId',
          },
        ),
      );
    } catch (e) {
      error = e.toString().replaceFirst('Exception: ', '');
      rethrow;
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  Future<Map<String, dynamic>> checkPaymentStatus(String orderId) async {
    return Map<String, dynamic>.from(
      await api.request(
        'POST',
        '/payments/reconcile',
        body: {'orderId': orderId},
        timeout: const Duration(seconds: 20),
      ),
    );
  }

  Future<bool> refreshPayment(String orderId) async {
    final result = await checkPaymentStatus(orderId);
    if (result['paid'] != true) return false;
    await Future.wait([loadOrders(), loadActiveOrder()]);
    return orders.any(
      (o) => o['id'].toString() == orderId && o['paymentStatus'] == 'PAID',
    );
  }
}
