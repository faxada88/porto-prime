import { Body, Controller, Get, Headers, HttpCode, Post } from '@nestjs/common';
import { AsaasPayoutService } from './asaas-payout.service.js';
@Controller('wallet/asaas')
export class AsaasPayoutController {
  constructor(private readonly payouts: AsaasPayoutService) {}
  @Post('webhook') @HttpCode(200)
  webhook(@Headers('asaas-access-token') token: string | undefined, @Body() body: unknown) { return this.payouts.webhook(token, body); }
  @Get('status')
  status(@Headers('authorization') authorization?: string) { return this.payouts.diagnostics(authorization); }
  @Post('reconcile')
  reconcile(@Body('transferId') id: string, @Headers('authorization') authorization?: string) { return this.payouts.adminReconcile(id, authorization); }
}
