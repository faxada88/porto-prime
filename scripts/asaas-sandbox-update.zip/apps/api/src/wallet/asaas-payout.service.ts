import { BadRequestException, ConflictException, Injectable, OnModuleDestroy, OnModuleInit, UnauthorizedException } from '@nestjs/common';
import { timingSafeEqual } from 'node:crypto';
import { PrismaService } from '../prisma/prisma.service.js';
import { RealtimeGateway } from '../realtime/realtime.gateway.js';
import { AuthService } from '../auth/auth.service.js';

class AsaasRequestRejected extends Error {}

@Injectable()
export class AsaasPayoutService implements OnModuleInit, OnModuleDestroy {
  private timer?: ReturnType<typeof setInterval>;
  private running = false;
  constructor(private readonly prisma: PrismaService, private readonly realtime: RealtimeGateway, private readonly auth: AuthService) {}
  private get db(): any { return this.prisma; }
  enabled() { return process.env.ASAAS_PAYOUTS_ENABLED === 'true'; }
  assertConfigured() {
    if (process.env.ASAAS_ENVIRONMENT !== 'sandbox' || !process.env.ASAAS_API_KEY?.trim()) {
      throw new BadRequestException('Saques Asaas exigem chave e ambiente sandbox configurados.');
    }
  }
  onModuleInit() {
    if (!this.enabled()) return;
    this.assertConfigured();
    this.timer = setInterval(() => { void this.tick().catch(() => undefined); }, 10000);
    this.timer.unref();
  }
  onModuleDestroy() { if (this.timer) clearInterval(this.timer); }
  private async api(path: string, body?: unknown) {
    this.assertConfigured();
    const response = await fetch('https://api-sandbox.asaas.com/v3' + path, {
      method: body === undefined ? 'GET' : 'POST',
      headers: { access_token: process.env.ASAAS_API_KEY!.trim(), 'Content-Type': 'application/json', 'User-Agent': 'PortoPrime-SandboxPayouts/1.0' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.timeout(15000),
      redirect: 'error',
    });
    const data = await response.json();
    if (!response.ok) {
      // Do not log provider bodies, keys, or credentials. Never retry POST blindly.
      if (body !== undefined && [400, 401, 403, 422].includes(response.status) && Array.isArray(data?.errors)) throw new AsaasRequestRejected('Solicitacao recusada pelo Asaas. Confira saldo, chave Pix e autorizacoes no sandbox.');
      throw new Error('ASAAS_HTTP_' + response.status);
    }
    return data;
  }
  async tick() {
    if (this.running || !this.enabled()) return;
    this.running = true;
    try {
      const queued = await this.db.asaasPayout.findMany({ where: { state: 'QUEUED' }, orderBy: { createdAt: 'asc' }, take: 5 });
      for (const payout of queued) await this.send(payout.withdrawalId);
      // Reconcile known IDs after missed webhooks; never resend transfers.
      const pending = await this.db.asaasPayout.findMany({ where: { state: { in: ['SENT', 'UNKNOWN'] }, transferId: { not: null }, updatedAt: { lt: new Date(Date.now() - 60000) } }, take: 10 });
      for (const payout of pending) {
        try { await this.reconcile(payout.transferId); } catch { /* reservation remains until verified */ }
      }
    } finally { this.running = false; }
  }
  async send(id: string) {
    const claimed = await this.db.asaasPayout.updateMany({ where: { withdrawalId: id, state: 'QUEUED' }, data: { state: 'SENDING' } });
    if (claimed.count !== 1) return;
    try {
      const w = await this.db.withdrawal.findUniqueOrThrow({ where: { id } });
      const key = w.pixKeyType === 'PHONE' ? w.pixKey.replace(/^\+55/, '') : w.pixKey;
      const transfer = await this.api('/transfers', {
        value: Number(w.amount), operationType: 'PIX', pixAddressKey: key,
        pixAddressKeyType: w.pixKeyType === 'RANDOM' ? 'EVP' : w.pixKeyType,
        externalReference: 'porto-withdrawal:' + id,
        description: 'Saque Porto Prime ' + id,
      });
      if (!transfer?.id) throw new Error('ASAAS_NO_TRANSFER_ID');
      await this.db.asaasPayout.updateMany({ where: { withdrawalId: id, state: 'SENDING' }, data: { transferId: transfer.id } });
      await this.apply(transfer, id);
    } catch (error) {
      if (error instanceof AsaasRequestRejected) { await this.rejectRequest(id); return; }
      // Includes uncertain requests: keep funds reserved until an operator verifies
      // absence of a transfer. HTTP/network errors alone do not prove no Pix was sent.
      await this.db.asaasPayout.updateMany({ where: { withdrawalId: id, state: 'SENDING' }, data: { state: 'UNKNOWN', lastError: 'Envio sem confirmacao. Conciliar antes de qualquer nova tentativa.' } });
    }
  }
  private async rejectRequest(id: string) {
    const courierId = await this.db.$transaction(async (tx: any) => {
      await tx.$queryRawUnsafe('SELECT "id" FROM "Withdrawal" WHERE "id" = $1 FOR UPDATE', id);
      const p = await tx.asaasPayout.findUnique({ where: { withdrawalId: id } });
      if (!p || p.state !== 'SENDING' || p.transferId) return null;
      const w = await tx.withdrawal.findUniqueOrThrow({ where: { id } });
      await tx.asaasPayout.update({ where: { withdrawalId: id }, data: { state: 'FAILED', providerStatus: 'REQUEST_REJECTED', lastError: 'Solicitacao recusada pelo Asaas. Confira saldo, chave e autorizacoes no sandbox.' } });
      await tx.withdrawal.update({ where: { id }, data: { status: 'REJECTED', processedAt: new Date() } });
      await tx.courierLedgerEntry.upsert({ where: { idempotencyKey: `withdrawal:${id}:reversal` }, update: {}, create: {
        courierId: w.courierId, type: 'REVERSAL', amount: w.amount, description: 'Estorno de saque Pix recusado', idempotencyKey: `withdrawal:${id}:reversal`, metadata: { withdrawalId: id, provider: 'ASAAS' },
      } });
      return w.courierId;
    });
    if (courierId) await this.notify(courierId);
  }
  private async notify(courierId: string) {
    const c = await this.db.courierProfile.findUnique({ where: { id: courierId }, select: { userId: true } });
    if (c) this.realtime.emitToUser(c.userId, 'wallet.updated', { at: new Date().toISOString() });
    this.realtime.emitToRole('ADMIN', 'wallet.updated', { courierId, at: new Date().toISOString() });
  }
  async apply(t: any, expectedId?: string) {
    const reference = String(t.externalReference ?? '');
    const id = expectedId ?? (reference.startsWith('porto-withdrawal:') ? reference.slice('porto-withdrawal:'.length) : '');
    if (!id || !t.id || reference !== 'porto-withdrawal:' + id) throw new ConflictException('Referencia Asaas nao corresponde ao saque.');
    const result = await this.db.$transaction(async (tx: any) => {
      await tx.$queryRawUnsafe('SELECT "id" FROM "Withdrawal" WHERE "id" = $1 FOR UPDATE', id);
      const w = await tx.withdrawal.findUnique({ where: { id } });
      const p = await tx.asaasPayout.findUnique({ where: { withdrawalId: id } });
      if (!w || !p || p.environment !== 'sandbox') throw new ConflictException('Saque Asaas nao encontrado.');
      if (p.transferId && p.transferId !== t.id) throw new ConflictException('Transferencia divergente.');
      const key = w.pixKeyType === 'PHONE' ? w.pixKey.replace(/^\+55/, '') : w.pixKey;
      const destination = t.bankAccount?.pixAddressKey ?? t.pixAddressKey;
      if (Number(t.value) !== Number(w.amount) || t.operationType !== 'PIX' || (destination != null && String(destination) !== key && String(destination) !== w.pixKey)) {
        throw new ConflictException('Valor ou destino Asaas divergente.');
      }
      if (['DONE', 'FAILED', 'CANCELLED'].includes(p.state)) return w;
      const state = String(t.status);
      const paid = state === 'DONE';
      const failed = state === 'FAILED' || state === 'CANCELLED';
      const receipt = typeof t.transactionReceiptUrl === 'string' && t.transactionReceiptUrl.startsWith('https://') ? t.transactionReceiptUrl : undefined;
      await tx.asaasPayout.update({ where: { withdrawalId: id }, data: { transferId: t.id, state: paid || failed ? state : 'SENT', providerStatus: state, lastError: failed ? 'Transferencia nao concluida pelo Asaas.' : null } });
      const row = await tx.withdrawal.update({ where: { id }, data: { status: paid ? 'PAID' : failed ? 'REJECTED' : 'PROCESSING', processedAt: paid || failed ? new Date() : null, ...(paid && receipt ? { receiptUrl: receipt } : {}) } });
      if (failed) await tx.courierLedgerEntry.upsert({ where: { idempotencyKey: `withdrawal:${id}:reversal` }, update: {}, create: {
        courierId: w.courierId, type: 'REVERSAL', amount: w.amount, description: 'Estorno de saque Pix nao concluido', idempotencyKey: `withdrawal:${id}:reversal`, metadata: { withdrawalId: id, provider: 'ASAAS', transferId: t.id },
      } });
      return row;
    });
    await this.notify(result.courierId);
    return result;
  }
  async reconcile(transferId: string) {
    if (!/^[a-zA-Z0-9_-]{1,100}$/.test(transferId)) throw new BadRequestException('ID invalido');
    const transfer = await this.api('/transfers/' + encodeURIComponent(transferId));
    return this.apply(transfer);
  }
  async webhook(token: string | undefined, body: any) {
    const expected = process.env.ASAAS_WEBHOOK_TOKEN ?? '';
    const a = Buffer.from(token ?? ''), b = Buffer.from(expected);
    if (b.length < 32 || a.length !== b.length || !timingSafeEqual(a, b)) throw new UnauthorizedException();
    if (!String(body?.event ?? '').startsWith('TRANSFER_')) return { received: true };
    const transferId = String(body?.transfer?.id ?? '');
    if (!/^[a-zA-Z0-9_-]{1,100}$/.test(transferId)) throw new BadRequestException('ID invalido');
    // Query authenticated provider API rather than trusting event order or values.
    const transfer = await this.api('/transfers/' + encodeURIComponent(transferId));
    if (!String(transfer?.externalReference ?? '').startsWith('porto-withdrawal:')) return { received: true };
    await this.apply(transfer);
    return { received: true };
  }
  async adminReconcile(transferId: string, authorization?: string) {
    const user = await this.auth.authenticate(authorization);
    if (user.role !== 'ADMIN') throw new UnauthorizedException();
    return this.reconcile(transferId);
  }
  async diagnostics(authorization?: string) {
    const user = await this.auth.authenticate(authorization);
    if (user.role !== 'ADMIN') throw new UnauthorizedException();
    return { enabled: this.enabled(), environment: 'sandbox', pending: await this.db.asaasPayout.findMany({ where: { state: { notIn: ['DONE', 'FAILED', 'CANCELLED'] } }, orderBy: { createdAt: 'asc' }, take: 100 }) };
  }
}
