import { AsaasPayoutService } from './asaas-payout.service.js';
import { AsaasPayoutController } from './asaas-payout.controller.js';
import { FinanceService } from './finance.service.js';
import { FinanceController } from './finance.controller.js';
import { Global, Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module.js';
import { WalletController } from './wallet.controller.js';
import { WalletService } from './wallet.service.js';

@Global()
@Module({
  imports: [AuthModule],
  controllers: [WalletController, FinanceController, AsaasPayoutController],
  providers: [WalletService, FinanceService, AsaasPayoutService],
  exports: [WalletService, FinanceService],
})
export class WalletModule {}
