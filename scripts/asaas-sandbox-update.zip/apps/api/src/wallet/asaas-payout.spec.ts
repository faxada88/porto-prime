import { afterEach, describe, expect, it, vi } from 'vitest';
vi.mock('../prisma/prisma.service.js', () => ({ PrismaService: class {} }));
vi.mock('../auth/auth.service.js', () => ({ AuthService: class {} }));
vi.mock('../realtime/realtime.gateway.js', () => ({ RealtimeGateway: class {} }));
import { AsaasPayoutService } from './asaas-payout.service.js';
import { WalletService } from './wallet.service.js';
function fixture() {
  let w: any = { id: 'w', courierId: 'c', amount: 10, pixKeyType: 'EMAIL', pixKey: 'test@example.test', status: 'PROCESSING' };
  let p: any = { withdrawalId: 'w', environment: 'sandbox', state: 'QUEUED', transferId: null };
  const entries: any[] = [];
  const db: any = {
    $queryRawUnsafe: vi.fn(),
    withdrawal: { findUnique: async () => w, findUniqueOrThrow: async () => w, update: async ({ data }: any) => (w = { ...w, ...data }) },
    asaasPayout: {
      findUnique: async () => p,
      update: async ({ data }: any) => (p = { ...p, ...data }),
      updateMany: async ({ where, data }: any) => { if (p.state !== where.state) return { count: 0 }; p = { ...p, ...data }; return { count: 1 }; },
    },
    courierProfile: { findUnique: async () => ({ userId: 'u' }) },
    courierLedgerEntry: { upsert: async ({ create }: any) => { if (!entries.some(e => e.idempotencyKey === create.idempotencyKey)) entries.push(create); } },
  };
  db.$transaction = async (fn: any) => { const ws = { ...w }, ps = { ...p }, count = entries.length; try { return await fn(db); } catch (e) { w = ws; p = ps; entries.length = count; throw e; } };
  const rt: any = { emitToUser: vi.fn(), emitToRole: vi.fn() };
  const auth: any = { authenticate: async () => ({ role: 'ADMIN' }) };
  const service = new AsaasPayoutService(db, rt, auth);
  const transfer = { id: 't', externalReference: 'porto-withdrawal:w', value: 10, operationType: 'PIX', status: 'DONE', bankAccount: { pixAddressKey: 'test@example.test' } };
  return { service, db, rt, auth, entries, transfer, get p() { return p; }, get w() { return w; } };
}
afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); vi.restoreAllMocks(); });
describe('Asaas sandbox payouts', () => {
  it('refuses production even when enabled', () => { vi.stubEnv('ASAAS_ENVIRONMENT', 'production'); vi.stubEnv('ASAAS_API_KEY', 'test'); expect(() => fixture().service.assertConfigured()).toThrow('sandbox'); });
  it('claims an outbox row once under simultaneous sends', async () => { const f = fixture(); const api = vi.spyOn(f.service as any, 'api').mockResolvedValue(f.transfer); await Promise.all([f.service.send('w'), f.service.send('w')]); expect(api).toHaveBeenCalledTimes(1); expect(f.w.status).toBe('PAID'); expect(f.entries).toHaveLength(0); });
  it('retains the reservation on timeout and does not resend', async () => { const f = fixture(); const api = vi.spyOn(f.service as any, 'api').mockRejectedValue(new Error('timeout')); await f.service.send('w'); await f.service.send('w'); expect(f.p.state).toBe('UNKNOWN'); expect(f.w.status).toBe('PROCESSING'); expect(f.entries).toHaveLength(0); expect(api).toHaveBeenCalledTimes(1); });
  it('maps random keys to EVP', async () => { const f = fixture(); f.w.pixKeyType = 'RANDOM'; const api = vi.spyOn(f.service as any, 'api').mockResolvedValue(f.transfer); await f.service.send('w'); expect(api.mock.calls[0][1]).toMatchObject({ pixAddressKeyType: 'EVP', externalReference: 'porto-withdrawal:w' }); });
  it('reverses a definitive refusal once', async () => { vi.stubEnv('ASAAS_ENVIRONMENT', 'sandbox'); vi.stubEnv('ASAAS_API_KEY', 'test'); vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: false, status: 400, json: async () => ({ errors: [{ code: 'insufficient_balance' }] }) })); const f = fixture(); await f.service.send('w'); await f.service.send('w'); expect(f.w.status).toBe('REJECTED'); expect(f.entries).toHaveLength(1); expect(f.entries[0].amount).toBe(10); });
  it.each(['FAILED', 'CANCELLED'])('returns funds once for %s and repeated callbacks', async status => { const f = fixture(); await f.service.apply({ ...f.transfer, status }); await f.service.apply({ ...f.transfer, status }); expect(f.entries).toHaveLength(1); expect(f.w.status).toBe('REJECTED'); });
  it('does not regress completed transfer on delayed status', async () => { const f = fixture(); await f.service.apply(f.transfer); await f.service.apply({ ...f.transfer, status: 'PENDING' }); expect(f.w.status).toBe('PAID'); });
  it('does not refund a blocked transfer', async () => { const f = fixture(); await f.service.apply({ ...f.transfer, status: 'BLOCKED' }); expect(f.w.status).toBe('PROCESSING'); expect(f.entries).toHaveLength(0); });
  it('rejects mismatched amount, reference and destination', async () => { const f = fixture(); for (const patch of [{ value: 99 }, { externalReference: 'other' }, { bankAccount: { pixAddressKey: 'other@example.test' } }]) await expect(f.service.apply({ ...f.transfer, ...patch }, 'w')).rejects.toThrow(); expect(f.w.status).toBe('PROCESSING'); });
  it('rejects webhook authentication before calling provider', async () => { vi.stubEnv('ASAAS_WEBHOOK_TOKEN', 'a'.repeat(40)); const f = fixture(); const api = vi.spyOn(f.service as any, 'api'); await expect(f.service.webhook('wrong', {})).rejects.toThrow(); expect(api).not.toHaveBeenCalled(); });
  it('uses live provider status, not webhook payload', async () => { vi.stubEnv('ASAAS_WEBHOOK_TOKEN', 'a'.repeat(40)); const f = fixture(); vi.spyOn(f.service as any, 'api').mockResolvedValue(f.transfer); await f.service.webhook('a'.repeat(40), { event: 'TRANSFER_FAILED', transfer: { id: 't', status: 'FAILED' } }); expect(f.w.status).toBe('PAID'); expect(f.entries).toHaveLength(0); });
  it('blocks manual admin settlement of an integrated withdrawal', async () => { const f = fixture(); const wallet = new WalletService(f.db, f.auth, f.rt); await expect(wallet.updateWithdrawalStatus('w', 'REJECTED')).rejects.toThrow('integrado'); expect(f.entries).toHaveLength(0); });
});
