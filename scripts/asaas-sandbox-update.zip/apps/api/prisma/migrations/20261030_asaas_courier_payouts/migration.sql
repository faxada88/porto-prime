CREATE TABLE IF NOT EXISTS "AsaasPayout" (
 "withdrawalId" TEXT PRIMARY KEY REFERENCES "Withdrawal"("id") ON DELETE RESTRICT,
 "requestKey" TEXT NOT NULL UNIQUE,
 "environment" TEXT NOT NULL DEFAULT 'sandbox',
 "state" TEXT NOT NULL DEFAULT 'QUEUED',
 "transferId" TEXT UNIQUE,
 "providerStatus" TEXT,
 "lastError" TEXT,
 "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
 "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS "AsaasPayout_state_updatedAt_idx" ON "AsaasPayout"("state", "updatedAt");
